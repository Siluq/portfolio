
* Favicon Generator readme

* Inhoud zip bestand:

 - favicon.ico - favicon.
 - preview_16x16.png - 16*16 PNG afbeelding van de favicon.
 - animated_favicon.gif - favicon met de scrollende tekst.
 - readme.txt - Instructies om de favicon toe te voegen aan uw website.
 
 -------------
 
 Wanneer u de standaard favicon wilt toe voegen aan uw website dan moet u de
 afbeelding favicon.ico uploaden naar de hoofd folder van uw website.
 Dit is de folder /www/uw-eigen-domeinnaam.nl/
 
 U kunt de afbeelding uploaden via de filemanager in het control panel.
 
 Alle moderne browsers zullen nu de favicon automatisch weergeven naast de URL in de
 adres balk van de browser.
 
 -------------
 
 Wilt u de favicon met de scrollende tekst toevoegen aan uw website dan moet u de
 afbeelding animated_favicon.gif uploaden naar de hoofd folder van uw website.
 Dit is de folder /www/uw-eigen-domeinnaam.nl/
 
 U kunt de afbeelding uploaden via de filemanager in het control panel.
 
 Daarna moet u de onderstaande HTML code toevoegen tussen de <head> ... </head>
 tags van uw webpagina's om de favicon zichtbaar te maken:
 
 <link rel="icon" href="animated_favicon.gif" type="image/gif" >

 -------------
	
  Your-webhost.nl
  http://www.your-webhost.nl